//<script type="text/javascript">


console.log("entered feedtest.js");

function displayCL (feedResponse) {

   var itemString = feedResponse.entries[0].content;
   var publishedDate = feedResponse.entries[0].publishedDate;

    // Clean up strings manually as needed

   //parse it
   var itemsArray = itemString.split("/");

   //unordered list
   var html = '<h2>' + feedResponse.entries[0].title + '</h2>';
    html += '<ul>';

    html += '<li>' + itemsArray[0] + '</li>';
    // Last 48 Hours
    html += '<li>' + itemsArray[1] + '</li>';
    // Snow condition
    html += '<li>' + itemsArray[2] + '</li>';
    // Base depth
    html += '<li>' + itemsArray[3] + '</li>';

    html += '<li>CL Report Date: ' + publishedDate + '</li>';

    html += '</ul>';

    $('body').append(html);
    console.log("DisplayCL " + html); 
} 

function parseRSS(url, callback) {
  console.log("parse RSS");
  $.ajax({
    url: document.location.protocol + '//ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=10&callback=?&q=' + encodeURIComponent(url),
    dataType: 'json',
    success: function(data) {
      callback(data.responseData.feed);
    }
  });
}

$(document).ready(function() {              

  console.log("document ready");

  parseRSS("http://sfbay.craigslist.org/search/muc?query=horn&srchType=A&format=rss",displayCL);
});

//</script>
