//These are node modules. They allow you to use node.js's APIs
var http = require('http'),
    url = require('url'),
    fs = require('fs'),
    path = require('path'),
    qs = require('querystring');


// http://nodejs.org/api/url.html - We'll be parsing the querystring with this.

console.log('script running');
//var header ='<!doctype html><html><head><title>My app</title></head><body><div class="header"><h1>Exercise 2-1 : enter email</h1>';
//var aForm = '<form method="POST" action="/form">First Name:<input name="first_name"><br>Last Name:<input name="last_name"><button type="submit">Submit</button></form>';

var header ='<!doctype html><html><head><title>Exercise 2-1 : Enter your email </title></head><body><div class="header"><h1>Exercise 2-1 : Enter email</h1>';
var goBack ='<a href="/">Go Back Home</a>';
var footer ='</body>';

http.createServer(function (request,response) {
    console.log('server running');

    var path = url.parse(request.url).pathname;
    var querystring = url.parse(request.url, true).query;  //return an object from a querystring with raw name-value pairs.
    var body = makeBody(path, querystring);
    response.writeHead(200, {
    'Content-Length': body.length,
    'Content-Type': 'text/html' });
    response.end(body);
}).listen(process.env.PORT);


function makeBody(path, querystring) {
    var body = header;
    var name = querystring.name || 'lady';

    switch (path) {
        case '/greeting':
            body += "Hello " + name + "!";
            body += goBack;
            break;
        case '/farewell':
            body += "Goodbye, " + name + ". :(";
            body += goBack;
            break;
        default:
            body += 'Hello! Please click one of the following links: ';
            body += '<ul>'
            body += '<li><a href="/greeting?name=Pamela">Greet Pamela</a></li>';
            body += '<li><a href="/greeting?name=Adria">Greet Adria</a></li>';
            body += '<li><a href="/farewell?name=Liz">Say goodbye to Liz</a></li>';
            body += '<li><a href="/farewell?name=You">Say goodbye to You</a></li>';
            body += '</ul>';
            break;
    }

    body += footer;
    return body;
}