

/* exercise 1 - modified to break out the server object, 
plus add another server object to listen in on another port. */

var http = require('http');
var fs = require('fs'),
    url = require('url'),
    httserver8080 = http.createServer(function (request,response) { /* handle request */
        
        console.log('createServer');
        var path = url.parse(request.url).pathname;
        
        console.log('createServer path = ' + path);
        path = '.' + path;
        getFile(path,function(err,body){
           console.log('calling getFile'); 
           response.writeHead(body.statusCode, {
        'Content-Length': body.length,
        'Content-Type': 'text/html' })
        response.end(body.body, 'utf-8');
        });
        
    }),
    
    httserver9090 = http.createServer(function (request,response) { /* handle request */
        
        console.log('createServer 9090');
        var path = url.parse(request.url).pathname;
        
        console.log('createServer 9090 path = ' + path);
        path = '.' + path;
        getFile(path,function(err,body){
           console.log('calling getFile from 9090'); 
           response.writeHead(body.statusCode, {
        'Content-Length': body.length,
        'Content-Type': 'text/html' })
        response.end(body.body, 'utf-8');
        });
        
    });

    
    httserver8080.listen(process.env.PORT);
   // httserver9090.listen(9090);
    /* looks like cloud9's servers don't allow non-standard ports.
       Try this from your own personal server. 
     */
    
    function getFile(path, callback) {
        console.log('entered getFile');
    var response = {};
    console.log('getFile path = ' + path);
    fs.readFile(path, function(err, data) {
        if (err) {
            console.log('found file failure');
            response.statusCode = 500;
            response.body = 'There was an error getting the requested file: ' + err;
            response.length = response.body.length;
            console.log(err);
        } else {
            console.log('found file success');
            response.statusCode = 200;
            response.body = data.toString();
            response.length = response.body.length;
        }
        callback(err, response);
    });
    };
    
    