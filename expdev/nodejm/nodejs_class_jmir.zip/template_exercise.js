/* Exercise 2-2 - template exercise: create login database, 
check login attempt against it
-- This example contains two examples of forms. 
-- The first form is a link to "/form" which collects a name and email address,
  then writes these all to a file "contactdata.txt" and outputs them as well 
   to the client browser. 
-- The second form is a link to "/login" which reads only a username. 
  This username is checked for existence in the "useraccounts.txt" file,
  and if it match is not found then this user is logged in a separate 
  "intrusions.txt" file. If the user is found, nothing is done.
-- There is a separate template exercise within which is in progress 
  i.e. not working yet. The template is only to be called from the "/login",
  which, after submit button, does a POST for "/login_new" path. This is 
  handled within an assembleDocument routine. The template should replace all
  occurrences of "name" with the useraccount name and serve a new doc 
  to that user based on their name, which emulates a login homepage.
*/

//These are node modules. They allow you to use node.js's APIs

var http = require('http'),
    url = require('url'),
    fs = require('fs'),
    path = require('path'),
    qs = require('querystring'),
    _ = require('underscore');

//HTML elements to be assembled
var header ='<!doctype html><html><head><title>My app</title></head><body><div class="header"><h1>Jenns NODE.js test server (courtesy cloud9)</h1>';
//var header ='<!doctype html><html><head><title>Basic server NODE.js demo</title></head><body><div class="header"><h1>This demo posts a form and writes the form data to a file.</h1>';
var aForm = '<form method="POST" action="/form">First Name:<input name="first_name"><br>Last Name:<input name="last_name">email:<input name="emailaddr"><button type="submit">Submit</button></form>';
var lForm = '<form method="POST" action="/login_new">user:<input name="user"><button type="submit">Submit</button></form>';
var goBack ='<a href="/">Go Back Home</a>';
var footer ='</body>';

//The server herself.
http.createServer(function (request,response) 
{
    console.log('entered createServer');
    //We're going to begin by adding things to the request object.
    request.form = '';

    //Parse querystring, since we have the entire thing immediately.
    request.querystring = url.parse(request.url, true).query;  //return an object from a querystring with raw name-value pairs.

    //Because request is an object that was only just created, and only exists in the scope of this server,
    //We're going to add listeners to the events it emits here.

    console.log('calling addListener data');
    //This event is emitted when we get a chunk of request body data.
    request.addListener('data', function(chunk) 
    {
        console.log('inside data');
        //handle a chunk of data, passed in as a buffer.
        //Buffers are easily transformed to strings.
        request.form += chunk.toString();
        console.log('request.form after chunk: ' + request.form);
    });

    console.log('calling addListener end');
    //This event is emitted when we reach the end of the request body.
    //In some cases, we might never reach the end, because the connection is prematurely closed. We want to check for that.
    request.addListener('end', function() 
    {
        if (request.method == 'POST') 
        {
            request.form = qs.parse(request.form);
            console.log('request.form after parsing: ' + request.form);
            // at this point the data is pretty raw and usable for text files.
            console.log('request.url = ' + request.url);
            var urltype = request.url;
            if (urltype == "/form")
            {
               var path = './contactdata.txt';
               var newData = request.form.first_name + ' ' + request.form.last_name + ' ' + request.form.emailaddr;
               fs.readFile(path, 'utf8', function(err, data)
               {
                   console.log(' old data looks like this: ' + data);
                   data += newData;
                   console.log(' new data looks like this: ' + data);
                   fs.writeFile(path, newData, 'utf8', function(err)
                   {
                      console.log('contactdata: any errors? ' + err);
                      console.log('wrote ' + newData + 'to ' + path);
                   });
               });
            }
            else if (urltype == "/login_new")
            {
              var path2 = './useraccounts.txt';                
              var username = request.form.user;
              fs.readFile(path2, 'utf8', function(err, data) 
              {
                var userexists = data.search(username);
                console.log('userexists = ' + userexists);
                if (userexists >= 0)
                {
                  // this user is in the useraccounts file.
                    // now find the template, and swap out their name.
                    // replacing the template creates a new homepage for the user.
                /*  var document = {};
                  document.path = url.parse(request.url).pathname;
                */
                }   
                else 
                {
                    fs.writeFile('intrusions.txt',username,'utf8',function(err)
                    {
                        console.log('intrusions err: ' + err);
                        request.url = "/farewell";
                    });
                }
              });
            }
        }
        
        //Request exists in a higher "scope" than this listener callback.
        //thus, we can use this property to indicate a "state". If we've "ended", it will be true. Otherwise, undefined.
        //This is useful in case a "close" event fires before "end".
        request.ended = true;
        assembleDocument(request, function(document) 
        {
            document.headers = getHeaders(document);
            response.writeHead(document.statusCode, document.headers);
            response.end(document.body);
        }); 

    }); // end request.addListener(end)

    console.log('calling addListener close');
    //This event is emitted when the connection is closed.
    request.addListener('close', function() {
        //Checking for an edge case, in this case, we didn't get the entire message.
        if (!request.ended) {
            //Request died midway through. Throw an error.
            request.terminated = true;
            return;
        }
    });

}).listen(process.env.PORT);


//this will return a document object with a body and some headers.
function assembleDocument(request, callback) {
    console.log('request.path in assembleDocument: ' + request.path);
    var document = {};
    document.path = url.parse(request.url).pathname;
    if (request.terminated){
        document.statusCode = 500;
        document.body = http.STATUS_CODES[500];
        callback(document);
    }

    var name = request.querystring.name || 'lady';

    document.body = header;
    switch (document.path) {
        case '/greeting':
            document.body += "Hello " + name + "!";
            document.body += goBack;
            break;
        case '/farewell':
            document.body += "Goodbye, " + name + ". :(";
            document.body += goBack;
            break;
        case '/login':
            document.body += lForm;
            document.type = 'text/html';
            //currentuser = request.form.user;
            console.log('assemble login: request.method = ' + request.method);
            console.log('assemble login: document.body = ' + document.body);
            if (request.method == 'POST')
            {
              var loginname = request.form.user;
              console.log('user = ' + request.form.user);
              var compiled = ' ';
              console.log('loginname = ' + loginname);
              /*
                fs.readFile('./templates/login_template.html', 'utf8', function(err,data) {
                    console.log(err);
                 
                    compiled = _.template(data,{name : loginname});
                    document.body += compiled;
                    console.log('new body = ' + document.body);
                    fs.writeFile('./templates/login_template_new.html',compiled);
                    // at this point the next doc displayed should be the new template,
                    // but doesn't work yet for some as yet unknown reason.
                });
            */
            }
            break;
        case '/form':
            document.body += aForm;
            document.type = 'text/html';
            if (request.method == 'POST') {
                document.body += 'Hello, ' + request.form.first_name;
                document.body += ' ' + request.form.last_name +'! <br>';
                document.body += 'email address: ' + request.form.emailaddr + '<br>';
                // document.body is in html encoded format.
                
            }
            document.body += goBack;
            break;
        case '/login_new':
            console.log('assembler login_new: document.body = ' + document.body);
            // display #1
            
            document.body += 'thanks for logging in ';
            document.body += request.form.user;  
            document.body += '</br><li><a href="/form">Go back to form</a></li>';
            document.body += '</br><li><a href="/login">Go back to login</a></li>';
            
            //display #2 - using template
            /*fs.readFile('./templates/login_template.html', 'utf8', function(err,data) 
            {
                console.log('template read err = ' + err);
                var username = request.form.user;
                var compiled = ' '; // initialized
                compiled = _.template(data,{name : username});
                document.body += compiled;
                console.log('template document.body = ' + document.body);
                fs.writeFile('./templates/login_template_new.html',compiled,'utf8',function(err)
                {
                    console.log('template err: ' + err);
                });
            });
            */
            // at this point the next doc displayed should be the new template,

            break;
        case '/':
            document.body += 'To enter form data to write to a file, <li><a href="/form">go here to Form</a></li>';
            document.body += '</br>To enter form data for use in a template, <li><a href="/login">go here to Login</a></li>';
            break;
        default:
            document.readFile = true;
            fs.readFile('.' + url.parse(request.url).pathname, function(err, data) {
                if (err) {
                    document.statusCode = 500;
                    document.body += http.STATUS_CODES[500] + '<br>OOOPS There was an error getting the requested file: ' + err;
                } else {
                    document.statusCode = 200;
                    document.body = data.toString();
                }
                callback(document);
                return;
            });
    }
    if (!document.readFile) {
        document.statusCode = 200;
        document.body += footer;
        callback(document);
    }
}

function getHeaders(document) {
    var headers = {
        'Content-Length' : document.body.length,
        'Content-Type' : getType(document)
    };
    return headers;
}

function getType(document) {
    //only if the status code is 200 do we need to really find out what we're serving up.
    var type = 'text/html';
    if (document.statusCode == 200) {
        switch (path.extname(document.path)) {

            case 'html':
                type = 'text/html';
                break;
            case 'js':
                type = 'text/javascript';
                break;
            case 'css':
                type = 'text/css';
                break;
            case 'png':
                type = 'image/png';
                break;
            case 'jpg':
            case 'jpeg':
                type = 'image/jpeg';
                break;
            case 'gif':
                type = 'image/gif';
                break;
            case 'ico':
                type = 'image/x-icon';
                break;
            default:
            break;
        }
    }
    return type;
}