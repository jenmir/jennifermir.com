

/* exercise 1 - heroku and git extensions 
  this is the simplest form of a server. 
  It only creates a server object, then listens. 
  The listener parses the string received on the http side
  and removes the url, then looks at the rest. The rest of the 
  string is assumed to be a filename local to the server.
  If that file exists, the server the serves it up. 
  If not, it returns an error. If the url alone is entered,
  i.e. no filename after it, then the error returned is EISDIR
  because "this is a directory." 
  e.g. http://nodejs_class.jenmir.c9.io/helloworld
*/

var http = require('http'),
    fs = require('fs'),
    url = require('url');
    
    http.createServer(function (request,response) { /* handle request */
        
        console.log('createServer');
        var path = url.parse(request.url).pathname;
        
        console.log('createServer path = ' + path);
        path = '.' + path;
        getFile(path,function(err,body){
           console.log('calling getFile'); 
           response.writeHead(body.statusCode, {
        'Content-Length': body.length,
        'Content-Type': 'text/html' })
        response.end(body.body, 'utf-8');
        });
        
    }).listen(process.env.PORT);
    
    
    function getFile(path, callback) {
        console.log('entered getFile');
    var response = {};
    console.log('getFile path = ' + path);
    fs.readFile(path, function(err, data) {
        if (err) {
            console.log('found file failure');
            response.statusCode = 500;
            response.body = 'There was an error getting the requested file: ' + err;
            response.length = response.body.length;
            console.log(err);
        } else {
            console.log('found file success');
            response.statusCode = 200;
            response.body = data.toString();
            response.length = response.body.length;
        }
        callback(err, response);
    });
    };
    
    