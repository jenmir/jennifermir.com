
document.write('welcome to the cloud9 node.js server.');
